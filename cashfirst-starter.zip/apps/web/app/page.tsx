'use client';
import { useState } from 'react';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { PlusCircle, DollarSign, FileText, Camera, PieChart } from 'lucide-react';

export default function MobileMVP() {
  const [screen, setScreen] = useState<'dashboard' | 'income' | 'expenses' | 'taxes' | 'incomeHistory' | 'expenseHistory'>('dashboard');

  return (
    <div style={{ width: '100%', height: '100vh', display: 'flex', flexDirection: 'column', background: '#F9FAFB' }}>
      <div style={{ padding: 16, background: '#4F46E5', color: 'white', fontSize: 18, fontWeight: 600 }}>
        CashFirst
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
        {screen === 'dashboard' && <Dashboard setScreen={setScreen} />}
        {screen === 'income' && <IncomeFlow setScreen={setScreen} />}
        {screen === 'expenses' && <ExpenseFlow setScreen={setScreen} />}
        {screen === 'taxes' && <TaxesView setScreen={setScreen} />}
        {screen === 'incomeHistory' && <IncomeHistory setScreen={setScreen} />}
        {screen === 'expenseHistory' && <ExpenseHistory setScreen={setScreen} />}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', background: 'white', borderTop: '1px solid #E5E7EB', padding: 8 }}>
        <NavButton icon={<PieChart size={18} />} label="Dashboard" onClick={() => setScreen('dashboard')} />
        <NavButton icon={<DollarSign size={18} />} label="Income" onClick={() => setScreen('income')} />
        <NavButton icon={<Camera size={18} />} label="Expenses" onClick={() => setScreen('expenses')} />
        <NavButton icon={<FileText size={18} />} label="Taxes" onClick={() => setScreen('taxes')} />
      </div>
    </div>
  );
}

function NavButton({ icon, label, onClick }: { icon: React.ReactNode, label: string, onClick: () => void }) {
  return (
    <button onClick={onClick} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', color: '#4B5563' }}>
      {icon}
      <span style={{ fontSize: 12, marginTop: 4 }}>{label}</span>
    </button>
  );
}

function Dashboard({ setScreen }: { setScreen: (s: any) => void }) {
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
        <StatCard title="Income" value="$12,430" />
        <StatCard title="Expenses" value="$5,220" />
        <StatCard title="Potential Tax Savings" value="$1,780" />
        <StatCard title="Deductible %" value="34%" />
      </div>

      <Button className="w-full" onClick={() => setScreen('income')}>
        <span style={{ display: 'inline-flex', alignItems: 'center' }}><PlusCircle style={{ marginRight: 8 }} size={16}/> Add Income</span>
      </Button>
      <Button className="w-full" variant="outline" onClick={() => setScreen('expenses')}>
        <span style={{ display: 'inline-flex', alignItems: 'center' }}><Camera style={{ marginRight: 8 }} size={16}/> Add Expense</span>
      </Button>
    </div>
  );
}

function StatCard({ title, value }: { title: string, value: string }) {
  return (
    <Card className="rounded-2xl">
      <CardContent className="p-4">
        <p style={{ fontSize: 12, color: '#6B7280' }}>{title}</p>
        <p style={{ fontSize: 20, fontWeight: 700 }}>{value}</p>
      </CardContent>
    </Card>
  );
}

function IncomeFlow({ setScreen }: { setScreen: (s: any) => void }) {
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      <h2 style={{ fontSize: 18, fontWeight: 600 }}>Add Income</h2>
      <Button className="w-full">Cash / Tip Entry</Button>
      <Button className="w-full" variant="outline">Deposit Check (Scan)</Button>
      <Button className="w-full" variant="outline">Import from Bank</Button>
      <Button className="w-full" onClick={() => setScreen('incomeHistory')}>View Income History</Button>
      <Button className="w-full" variant="ghost" onClick={() => setScreen('dashboard')}>Back to Dashboard</Button>
    </div>
  );
}

function ExpenseFlow({ setScreen }: { setScreen: (s: any) => void }) {
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      <h2 style={{ fontSize: 18, fontWeight: 600 }}>Add Expense</h2>
      <Button className="w-full">Scan Receipt</Button>
      <Button className="w-full" variant="outline">Manual Entry</Button>
      <Button className="w-full" onClick={() => setScreen('expenseHistory')}>View Expense History</Button>
      <Button className="w-full" variant="ghost" onClick={() => setScreen('dashboard')}>Back to Dashboard</Button>
    </div>
  );
}

function TaxesView({ setScreen }: { setScreen: (s: any) => void }) {
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      <h2 style={{ fontSize: 18, fontWeight: 600 }}>Taxes Overview</h2>
      <Card className="rounded-2xl">
        <CardContent className="p-4">
          <p style={{ fontSize: 12, color: '#6B7280' }}>Year-to-Date Summary</p>
          <p style={{ fontSize: 20, fontWeight: 700 }}>Est. Refund: $1,200</p>
        </CardContent>
      </Card>
      <div style={{ display: 'grid', gap: 4 }}>
        <p style={{ fontSize: 14, fontWeight: 600 }}>Possible Write-Offs</p>
        <ul style={{ margin: 0, paddingLeft: 16, color: '#374151' }}>
          <li>Uniforms — $300</li>
          <li>Supplies — $500</li>
          <li>Travel/Mileage — $400</li>
        </ul>
      </div>
      <Button className="w-full">Export Tax Package</Button>
      <Button className="w-full" variant="ghost" onClick={() => setScreen('dashboard')}>Back to Dashboard</Button>
    </div>
  );
}

function IncomeHistory({ setScreen }: { setScreen: (s: any) => void }) {
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      <h2 style={{ fontSize: 18, fontWeight: 600 }}>Income History</h2>
      <ul style={{ display: 'grid', gap: 8 }}>
        <li style={{ padding: 12, background: 'white', borderRadius: 12, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>08/19 — $120 (Cash Tip)</li>
        <li style={{ padding: 12, background: 'white', borderRadius: 12, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>08/18 — $250 (Check)</li>
        <li style={{ padding: 12, background: 'white', borderRadius: 12, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>08/15 — $80 (Cash Tip)</li>
      </ul>
      <Button className="w-full" variant="ghost" onClick={() => setScreen('income')}>Back</Button>
    </div>
  );
}

function ExpenseHistory({ setScreen }: { setScreen: (s: any) => void }) {
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      <h2 style={{ fontSize: 18, fontWeight: 600 }}>Expense History</h2>
      <ul style={{ display: 'grid', gap: 8 }}>
        <li style={{ padding: 12, background: 'white', borderRadius: 12, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>08/19 — $45 (Meals) — Potential Write-Off</li>
        <li style={{ padding: 12, background: 'white', borderRadius: 12, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>08/18 — $100 (Supplies) — Potential Write-Off</li>
        <li style={{ padding: 12, background: 'white', borderRadius: 12, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>08/15 — $30 (Uniform) — Potential Write-Off</li>
      </ul>
      <Button className="w-full" variant="ghost" onClick={() => setScreen('expenses')}>Back</Button>
    </div>
  );
}
