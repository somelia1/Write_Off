# CashFirst (working title) — Side Income & Write‑Off Tracker

Mobile‑first web app to log income, capture receipts with OCR, auto‑categorize expenses, surface potential write‑offs, and export a tax‑ready package. The MVP centers on four tabs: **Dashboard**, **Income**, **Expenses**, and **Taxes**, plus **History** views for both income and expenses.

---

## Features (MVP)
- One‑tap cash/tip logging; check deposit (scan) and bank/digital import stubs.
- Receipt capture with OCR + AI‑assisted categorization and deductible suggestions (rules first, ML later). Auto‑accept ≥ 0.85 confidence.
- Dashboard with yearly income, expenses, and potential tax savings cards.
- Taxes view with YTD summary, possible write‑offs, and export to CSV/XLSX/QuickBooks‑ready CSV.
- Offline‑first posture, secure storage, privacy defaults (scaffolded at MVP).
- Estimated tax calculator stub + quarterly reminder hook.

**Backlog highlights:** manual mileage tracking, Plaid adapter, tagging rules editor, CPA sharing link; future: auto‑mileage, ML OCR corrections, concierge CPA.

---

## Tech Stack
- **Next.js (App Router) + React + TypeScript**
- **Tailwind CSS** and **shadcn/ui** (lightweight stubs included here so it runs out of the box)
- **Zod** for request validation (optional for MVP)
- **Drizzle or Prisma** for models (SQLite in dev) — not required to run this starter

---

## Monorepo Layout (suggested)
```
apps/
  web/                # Next.js app (mobile-first UI)
packages/
  ui/                 # Shared UI components (cards, inputs, nav)
services/
  ocr/                # OCR adapter interface + mocks
  categorizer/        # Rules engine + confidence bands + explanations
  export/             # CSV/XLSX formatters (incl QuickBooks-ready)
  reminders/          # Quarterly reminders / scheduler stub
docs/
  CashFirst_TaxAssistant_Discussion.pdf  # product notes
prototypes/
  side_income_tracker.jsx                # initial prototype
```

This starter only includes `apps/web` and lightweight stubs plus the docs/prototype. Add the other workspaces as you implement services.

---

## Getting Started

### 1) Prerequisites
- Node.js 20+ and pnpm (or yarn/npm)

### 2) Install & Run
```bash
cd apps/web
pnpm install
pnpm dev
# or: npm install && npm run dev
```

Visit `http://localhost:3000`.

---

## Roadmap
- **P0**: onboarding, one‑tap income, OCR receipts (mock), list views, exports, offline sync (scaffold), estimated‑tax reminders, privacy controls.
- **P1**: manual mileage, Plaid integration, tagging rules, CPA sharing.

---

## License
MIT — see [LICENSE](../LICENSE).
